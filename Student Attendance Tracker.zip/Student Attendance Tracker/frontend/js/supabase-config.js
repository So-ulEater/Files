// Get the Supabase client from the global scope
const { createClient } = supabase;

// Initialize the Supabase client
const supabaseUrl = 'https://zbdgnwoebpizotsqrlsv.supabase.co'
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpiZGdud29lYnBpem90c3FybHN2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY5NTE5MDEsImV4cCI6MjA2MjUyNzkwMX0.z4CaT6GGFYZCepVKaf7HsAG8NP8fRuPZkIrpzpMmbts'

// Create and export the Supabase client
const supabaseClient = createClient(supabaseUrl, supabaseKey)

// Make it available globally
window.supabase = supabaseClient

// Test the connection
async function testConnection() {
    try {
        const { data, error } = await window.supabase
            .from('students')
            .select('*')
            .limit(1);
        
        if (error) {
            console.error('Supabase connection error:', error);
            return false;
        }
        
        console.log('Supabase connection successful!');
        return true;
    } catch (error) {
        console.error('Supabase connection error:', error);
        return false;
    }
}

// Test the connection immediately
testConnection();

// For testing purposes, let's disable RLS temporarily
// Go to your Supabase dashboard -> Authentication -> Policies
// And disable RLS for the students table temporarily 