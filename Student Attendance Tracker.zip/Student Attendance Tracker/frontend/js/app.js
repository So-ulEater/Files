// Add this at the beginning of the file
async function testSupabaseConnection() {
    try {
        console.log('Testing Supabase connection...');
        const { data, error } = await window.supabase
            .from('students')
            .select('*')
            .limit(1);
        
        if (error) {
            console.error('Supabase connection error:', error);
            return false;
        }
        
        console.log('Supabase connection successful!');
        return true;
    } catch (error) {
        console.error('Supabase connection error:', error);
        return false;
    }
}

// Add this function to test Supabase access
async function testSupabaseAccess() {
    try {
        console.log('Testing Supabase access...');
        
        // Test students table
        const { data: students, error: studentsError } = await window.supabase
            .from('students')
            .select('*')
            .limit(1);
            
        if (studentsError) {
            console.error('Error accessing students table:', studentsError);
            return false;
        }
        
        console.log('Successfully accessed students table');
        return true;
    } catch (error) {
        console.error('Error testing Supabase access:', error);
        return false;
    }
}

// Add this at the top of app.js
let studentCount = 0;

// Initialize dashboard data
async function initializeDashboard() {
    try {
        console.log('Initializing dashboard...');
        
        // First check if we're authenticated
        if (localStorage.getItem('isAuthenticated') !== 'true') {
            window.location.href = 'login.html';
            return;
        }

        // Get total students
        const { data: students, error: studentsError } = await window.supabase
            .from('students')
            .select('*');
        
        if (studentsError) {
            console.error('Error getting students count:', studentsError);
            throw studentsError;
        }
        
        studentCount = students?.length || 0;
        console.log('Total students:', studentCount);
        const totalStudentsElement = document.getElementById('totalStudents');
        if (totalStudentsElement) {
            totalStudentsElement.textContent = studentCount;
        }

        // Get total courses
        const { data: courses, error: coursesError } = await window.supabase
            .from('courses')
            .select('id', { count: 'exact' });
        
        if (coursesError) {
            console.error('Error getting courses count:', coursesError);
            throw coursesError;
        }
        
        console.log('Total courses:', courses?.length || 0);
        document.getElementById('totalCourses').textContent = courses?.length || 0;

        // Get today's attendance
        const today = new Date().toISOString().split('T')[0];
        const { data: todayAttendance, error: attendanceError } = await window.supabase
            .from('attendance')
            .select('id', { count: 'exact' })
            .eq('date', today)
            .eq('status', 'present');
        
        if (attendanceError) {
            console.error('Error getting today\'s attendance:', attendanceError);
            throw attendanceError;
        }
        
        console.log('Today\'s attendance:', todayAttendance?.length || 0);
        document.getElementById('todayAttendance').textContent = todayAttendance?.length || 0;

        // Get recent attendance
        const { data: recentAttendance, error: recentError } = await window.supabase
            .from('attendance')
            .select(`
                *,
                students (name, student_id),
                courses (name)
            `)
            .order('date', { ascending: false })
            .limit(5);
        
        if (recentError) throw recentError;

        const recentAttendanceTable = document.getElementById('recentAttendance');
        if (recentAttendanceTable) {
            recentAttendanceTable.innerHTML = recentAttendance.map(record => `
                <tr onclick="window.location.href='attendance-list.html?date=${record.date}'" style="cursor: pointer;">
                    <td>${new Date(record.date).toLocaleDateString()}</td>
                    <td>${record.students?.student_id || 'N/A'}</td>
                    <td>${record.students?.name || 'N/A'}</td>
                    <td>${record.courses?.name || 'No Course'}</td>
                    <td>${record.status === 'present' ? '✓' : ''}</td>
                    <td>${record.status === 'late' ? '✓' : ''}</td>
                    <td>${record.status === 'absent' ? '✓' : ''}</td>
                </tr>
            `).join('');
        }
    } catch (error) {
        console.error('Error initializing dashboard:', error);
        alert('Error loading dashboard data: ' + error.message);
    }
}

// Add this at the beginning of the file
async function checkAuthState() {
    try {
        const { data: { user }, error } = await window.supabase.auth.getUser();
        if (error) throw error;
        
        if (!user) {
            console.log('No user found, redirecting to login...');
            window.location.href = 'login.html';
            return false;
        }
        
        console.log('User authenticated:', user.email);
        localStorage.setItem('isAuthenticated', 'true');
        return true;
    } catch (error) {
        console.error('Auth state error:', error);
        window.location.href = 'login.html';
        return false;
    }
}

// Initialize when the page loads
document.addEventListener('DOMContentLoaded', () => {
    // Check authentication first
    if (localStorage.getItem('isAuthenticated') !== 'true') {
        window.location.href = 'login.html';
        return;
    }

    // Then initialize dashboard
    initializeDashboard();
});

// Add these functions at the top of app.js
async function loadCourses() {
    try {
        console.log('Loading courses...');
        const { data: courses, error } = await window.supabase
            .from('courses')
            .select('*')
            .order('name');

        if (error) {
            console.error('Error loading courses:', error);
            throw error;
        }

        console.log('Courses loaded:', courses);

        const courseSelect = document.getElementById('courseSelect');
        const reportCourse = document.getElementById('reportCourse');
        const studentCourse = document.getElementById('studentCourse');
        
        if (courseSelect) {
            courseSelect.innerHTML = '<option value="">Select a course</option>' + 
                courses.map(course => `<option value="${course.id}">${course.name}</option>`).join('');
        }
        
        if (reportCourse) {
            reportCourse.innerHTML = '<option value="">All Courses</option>' + 
                courses.map(course => `<option value="${course.id}">${course.name}</option>`).join('');
        }

        if (studentCourse) {
            studentCourse.innerHTML = '<option value="">Select a course</option>' + 
                courses.map(course => `<option value="${course.id}">${course.name}</option>`).join('');
        }
    } catch (error) {
        console.error('Error loading courses:', error);
        alert('Error loading courses: ' + error.message);
    }
}

async function loadStudentsForAttendance() {
    try {
        console.log('Loading students for attendance...');
        const { data: students, error } = await window.supabase
            .from('students')
            .select(`
                *,
                courses (id, name)
            `)
            .order('name');

        if (error) {
            console.error('Error loading students:', error);
            throw error;
        }

        console.log('Students loaded:', students);

        const studentList = document.getElementById('studentList');
        if (studentList) {
            studentList.innerHTML = students.map(student => `
                <tr>
                    <td>${student.student_id}</td>
                    <td>${student.name}</td>
                    <td>${student.courses?.name || 'No Course'}</td>
                    <td>
                        <select name="attendance" class="attendance-status" 
                            data-student-id="${student.id}" 
                            data-course-id="${student.course_id || ''}">
                            <option value="present">Present</option>
                            <option value="late">Late</option>
                            <option value="absent">Absent</option>
                        </select>
                    </td>
                </tr>
            `).join('');
        }

        // Set today's date as default
        const dateInput = document.getElementById('date');
        if (dateInput) {
            const today = new Date().toISOString().split('T')[0];
            dateInput.value = today;
        }
    } catch (error) {
        console.error('Error loading students:', error);
        alert('Error loading students: ' + error.message);
    }
}

// Add this function to handle section navigation
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.form-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show the selected section
    const selectedSection = document.getElementById(sectionId);
    if (selectedSection) {
        selectedSection.classList.add('active');
    }
    
    // Update header title
    const headerTitle = document.querySelector('.header h1');
    if (headerTitle) {
        headerTitle.textContent = selectedSection.querySelector('h2')?.textContent || 'Dashboard';
    }
}

// Update the menu items click handler
document.addEventListener('DOMContentLoaded', async () => {
    try {
        console.log('Page loaded');
        
        // Test Supabase connection
        const { data, error } = await window.supabase
            .from('students')
            .select('*')
            .limit(1);
        
        if (error) {
            console.error('Supabase connection error:', error);
            alert('Error connecting to database. Please try again.');
            return;
        }

        // Initialize dashboard
        await initializeDashboard();
        await loadCourses();
        await loadStudentsForAttendance();

        // Menu items
        const menuItems = document.querySelectorAll('.menu-item');
        console.log('Found menu items:', menuItems.length);
        
        menuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.currentTarget.dataset.section;
                console.log('Menu item clicked:', section);
                showSection(section);
            });
        });

        // Add Course form handler
        const addCourseForm = document.getElementById('addCourseForm');
        if (addCourseForm) {
            addCourseForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const courseData = {
                    code: document.getElementById('courseCode').value,
                    name: document.getElementById('courseName').value,
                    description: document.getElementById('courseDescription').value
                };

                try {
                    console.log('Adding course:', courseData);
                    
                    // First check if course code already exists
                    const { data: existingCourse, error: checkError } = await window.supabase
                        .from('courses')
                        .select('code')
                        .eq('code', courseData.code)
                        .single();

                    if (checkError && checkError.code !== 'PGRST116') { // PGRST116 is "no rows returned"
                        throw checkError;
                    }

                    if (existingCourse) {
                        alert('Course Code already exists!');
                        return;
                    }

                    // Insert the new course
                    const { data, error } = await window.supabase
                        .from('courses')
                        .insert([courseData])
                        .select();

                    if (error) {
                        console.error('Error adding course:', error);
                        alert('Error adding course: ' + error.message);
                        return;
                    }

                    console.log('Course added successfully:', data);
                    alert('Course added successfully!');
                    e.target.reset();
                    
                    // Refresh all relevant data
                    await initializeDashboard();
                    await loadCourses();
                    
                } catch (error) {
                    console.error('Error adding course:', error);
                    alert('Error adding course: ' + error.message);
                }
            });
        }

        // Add Student form handler
        const addStudentForm = document.getElementById('addStudentForm');
        if (addStudentForm) {
            addStudentForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const studentData = {
                    student_id: document.getElementById('studentId').value,
                    name: document.getElementById('studentName').value,
                    email: document.getElementById('studentEmail').value,
                    phone: document.getElementById('studentPhone').value,
                    course_id: document.getElementById('studentCourse').value
                };

                try {
                    console.log('Adding student:', studentData);
                    
                    // First check if student_id already exists
                    const { data: existingStudent, error: checkError } = await window.supabase
                        .from('students')
                        .select('student_id')
                        .eq('student_id', studentData.student_id)
                        .single();

                    if (checkError && checkError.code !== 'PGRST116') { // PGRST116 is "no rows returned"
                        throw checkError;
                    }

                    if (existingStudent) {
                        alert('Student ID already exists!');
                        return;
                    }

                    // Insert the new student
                    const { data, error } = await window.supabase
                        .from('students')
                        .insert([studentData])
                        .select();

                    if (error) {
                        console.error('Error adding student:', error);
                        alert('Error adding student: ' + error.message);
                        return;
                    }

                    console.log('Student added successfully:', data);
                    alert('Student added successfully!');
                    e.target.reset();
                    
                    // Refresh all relevant data
                    await initializeDashboard();
                    await loadStudentsForAttendance();
                    
                } catch (error) {
                    console.error('Error adding student:', error);
                    alert('Error adding student: ' + error.message);
                }
            });
        }

        // Add click handler for students card
        const studentsCard = document.querySelector('.card[onclick*="students-list.html"]');
        if (studentsCard) {
            studentsCard.onclick = navigateToStudentsList;
        }

        // Mark Attendance form handler
        const markAttendanceForm = document.getElementById('markAttendanceForm');
        if (markAttendanceForm) {
            markAttendanceForm.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const date = document.getElementById('date').value;
                const statusSelects = document.querySelectorAll('.attendance-status');
                
                try {
                    console.log('Preparing attendance records...');
                    
                    const attendanceRecords = Array.from(statusSelects)
                        .filter(select => {
                            const studentId = select.dataset.studentId;
                            const courseId = select.dataset.courseId;
                            
                            console.log('Student ID:', studentId);
                            console.log('Course ID:', courseId);
                            
                            // Skip students without courses
                            if (!courseId) {
                                console.log('Skipping student without course:', studentId);
                                return false;
                            }
                            return true;
                        })
                        .map(select => ({
                            student_id: select.dataset.studentId,
                            course_id: select.dataset.courseId,
                            date: date,
                            status: select.value
                        }));

                    if (attendanceRecords.length === 0) {
                        alert('No valid attendance records to save. Please assign courses to students first.');
                        return;
                    }

                    console.log('Attendance records to save:', attendanceRecords);

                    // First, delete existing attendance records for this date
                    const { error: deleteError } = await window.supabase
                        .from('attendance')
                        .delete()
                        .eq('date', date);

                    if (deleteError) {
                        console.error('Error deleting existing attendance:', deleteError);
                        throw deleteError;
                    }

                    // Then insert the new attendance records
                    const { data, error } = await window.supabase
                        .from('attendance')
                        .insert(attendanceRecords)
                        .select();

                    if (error) {
                        console.error('Error saving attendance:', error);
                        alert('Error saving attendance: ' + error.message);
                        return;
                    }

                    // Track late instances
                    const lateRecords = attendanceRecords
                        .filter(record => record.status === 'late')
                        .map(record => ({
                            student_id: record.student_id,
                            course_id: record.course_id,
                            date: record.date
                        }));

                    if (lateRecords.length > 0) {
                        console.log('Saving late records:', lateRecords);
                        
                        // Insert late records one by one to handle potential conflicts
                        for (const record of lateRecords) {
                            try {
                                const { error: lateError } = await window.supabase
                                    .from('late_tracking')
                                    .insert(record);

                                if (lateError) {
                                    console.error('Error tracking late instance:', lateError);
                                    // Continue with other records even if one fails
                                    continue;
                                }
                                console.log('Late record saved successfully:', record);
                            } catch (error) {
                                console.error('Error saving late record:', error);
                                // Continue with other records
                                continue;
                            }
                        }
                    }

                    console.log('Attendance saved successfully:', data);
                    alert('Attendance saved successfully!');
                    
                    // Refresh dashboard data
                    await initializeDashboard();
                    
                } catch (error) {
                    console.error('Error saving attendance:', error);
                    alert('Error saving attendance: ' + error.message);
                }
            });
        }

    } catch (error) {
        console.error('Initialization error:', error);
        alert('Error initializing application: ' + error.message);
    }
});

// Update the dashboard cards to be clickable
document.addEventListener('DOMContentLoaded', () => {
    // Make cards clickable
    const studentsCard = document.querySelector('.card[data-card="students"]');
    const coursesCard = document.querySelector('.card[data-card="courses"]');
    const attendanceCard = document.querySelector('.card[data-card="attendance"]');

    if (studentsCard) {
        studentsCard.addEventListener('click', () => {
            window.location.href = 'students-list.html';
        });
    }

    if (coursesCard) {
        coursesCard.addEventListener('click', () => {
            window.location.href = 'courses-list.html';
        });
    }

    if (attendanceCard) {
        attendanceCard.addEventListener('click', () => {
            window.location.href = 'attendance-list.html';
        });
    }
});

// Add this function to handle navigation
function navigateToStudentsList() {
    // Store the current count before navigation
    localStorage.setItem('studentCount', studentCount);
    window.location.href = 'students-list.html';
} 