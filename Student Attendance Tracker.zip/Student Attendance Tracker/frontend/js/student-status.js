// Function to load student status
async function loadStudentStatus() {
    console.log('Loading student status...');
    const statusTable = document.getElementById('statusTable');
    const loadingMsg = document.getElementById('loadingMsg');
    const noRecordsMsg = document.getElementById('noRecordsMsg');

    if (!statusTable || !loadingMsg || !noRecordsMsg) {
        console.error('Required elements not found');
        return;
    }

    try {
        loadingMsg.style.display = 'block';
        noRecordsMsg.style.display = 'none';
        statusTable.style.display = 'none';

        // Get all students with their courses
        const { data: students, error: studentsError } = await window.supabase
            .from('students')
            .select(`
                *,
                courses (name)
            `)
            .order('name');

        if (studentsError) throw studentsError;
        console.log('Students loaded:', students);

        if (!students || students.length === 0) {
            loadingMsg.style.display = 'none';
            noRecordsMsg.style.display = 'block';
            return;
        }

        // Get late counts for each student
        const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        console.log('Fetching late counts since:', thirtyDaysAgo);

        const { data: lateCounts, error: lateError } = await window.supabase
            .from('late_tracking')
            .select('student_id, course_id, count(*)')
            .gte('date', thirtyDaysAgo)
            .group('student_id, course_id');

        if (lateError) throw lateError;
        console.log('Late counts:', lateCounts);

        // Get pink slips
        const { data: pinkSlips, error: pinkSlipError } = await window.supabase
            .from('pink_slips')
            .select('*')
            .eq('status', 'active');

        if (pinkSlipError) throw pinkSlipError;
        console.log('Pink slips:', pinkSlips);

        // Create maps for quick lookup
        const lateCountMap = new Map();
        lateCounts?.forEach(count => {
            const key = `${count.student_id}-${count.course_id}`;
            lateCountMap.set(key, parseInt(count.count));
            console.log(`Late count for ${key}: ${count.count}`);
        });

        const pinkSlipMap = new Map();
        pinkSlips?.forEach(slip => {
            const key = `${slip.student_id}-${slip.course_id}`;
            pinkSlipMap.set(key, slip);
            console.log(`Pink slip for ${key}:`, slip);
        });

        // Generate table content
        const tbody = statusTable.querySelector('tbody');
        tbody.innerHTML = students.map(student => {
            const courseId = student.course_id;
            const key = `${student.id}-${courseId}`;
            const lateCount = lateCountMap.get(key) || 0;
            const pinkSlip = pinkSlipMap.get(key);
            const totalAbsences = Math.floor(lateCount / 3); // Every 3 lates = 1 absence

            console.log(`Student ${student.name} (${student.id}):`, {
                courseId,
                lateCount,
                hasPinkSlip: !!pinkSlip,
                totalAbsences
            });

            let statusBadge = '';
            if (pinkSlip) {
                statusBadge = '<span class="badge bg-danger">Active</span>';
            } else if (lateCount >= 3) {
                statusBadge = '<span class="badge bg-warning">Eligible</span>';
            } else {
                statusBadge = '<span class="badge bg-success">None</span>';
            }

            return `
                <tr>
                    <td>${student.student_id}</td>
                    <td>${student.name}</td>
                    <td>${student.courses?.name || 'No Course'}</td>
                    <td>${lateCount}</td>
                    <td>${totalAbsences}</td>
                    <td>${statusBadge}</td>
                    <td>
                        ${!pinkSlip && lateCount >= 3 ? 
                            `<button class="btn btn-warning btn-sm" onclick="generatePinkSlip('${student.id}', '${courseId}')">
                                <i class="fas fa-file-alt"></i> Generate Pink Slip
                            </button>` :
                            pinkSlip ? 
                            `<button class="btn btn-info btn-sm" onclick="viewPinkSlip('${pinkSlip.id}')">
                                <i class="fas fa-eye"></i> View Pink Slip
                            </button>` :
                            ''
                        }
                        <button class="btn btn-primary btn-sm" onclick="viewAttendanceHistory('${student.id}')">
                            <i class="fas fa-history"></i> View History
                        </button>
                    </td>
                </tr>
            `;
        }).join('');

        loadingMsg.style.display = 'none';
        statusTable.style.display = 'table';
        console.log('Student status table updated');

    } catch (error) {
        console.error('Error loading student status:', error);
        loadingMsg.style.display = 'none';
        noRecordsMsg.textContent = 'Error loading student status: ' + error.message;
        noRecordsMsg.style.display = 'block';
    }
}

// Function to generate a pink slip
async function generatePinkSlip(studentId, courseId) {
    try {
        const { data, error } = await window.supabase
            .from('pink_slips')
            .insert([{
                student_id: studentId,
                course_id: courseId,
                issue_date: new Date().toISOString().split('T')[0],
                reason: 'Three late instances in 30 days'
            }]);

        if (error) throw error;

        alert('Pink slip generated successfully!');
        loadStudentStatus(); // Refresh the table
    } catch (error) {
        console.error('Error generating pink slip:', error);
        alert('Error generating pink slip: ' + error.message);
    }
}

// Function to view a pink slip
async function viewPinkSlip(pinkSlipId) {
    try {
        const { data: pinkSlip, error } = await window.supabase
            .from('pink_slips')
            .select(`
                *,
                students (name, student_id),
                courses (name)
            `)
            .eq('id', pinkSlipId)
            .single();

        if (error) throw error;

        // Create a modal to display the pink slip
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.innerHTML = `
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Pink Slip Details</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p><strong>Student:</strong> ${pinkSlip.students.name} (${pinkSlip.students.student_id})</p>
                        <p><strong>Course:</strong> ${pinkSlip.courses.name}</p>
                        <p><strong>Issue Date:</strong> ${new Date(pinkSlip.issue_date).toLocaleDateString()}</p>
                        <p><strong>Reason:</strong> ${pinkSlip.reason}</p>
                        <p><strong>Status:</strong> ${pinkSlip.status}</p>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        const modalInstance = new bootstrap.Modal(modal);
        modalInstance.show();

        // Clean up the modal when it's hidden
        modal.addEventListener('hidden.bs.modal', () => {
            document.body.removeChild(modal);
        });
    } catch (error) {
        console.error('Error viewing pink slip:', error);
        alert('Error viewing pink slip: ' + error.message);
    }
}

// Function to view attendance history
async function viewAttendanceHistory(studentId) {
    try {
        const { data: history, error } = await window.supabase
            .from('attendance')
            .select(`
                *,
                courses (name)
            `)
            .eq('student_id', studentId)
            .order('date', { ascending: false });

        if (error) throw error;

        // Create a modal to display the history
        const modal = document.createElement('div');
        modal.className = 'modal fade';
        modal.innerHTML = `
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Attendance History</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Course</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${history.map(record => `
                                    <tr>
                                        <td>${new Date(record.date).toLocaleDateString()}</td>
                                        <td>${record.courses.name}</td>
                                        <td>${record.status}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        const modalInstance = new bootstrap.Modal(modal);
        modalInstance.show();

        // Clean up the modal when it's hidden
        modal.addEventListener('hidden.bs.modal', () => {
            document.body.removeChild(modal);
        });
    } catch (error) {
        console.error('Error viewing attendance history:', error);
        alert('Error viewing attendance history: ' + error.message);
    }
}

// Add search functionality
document.getElementById('studentFilter').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('#studentStatusTable tbody tr');

    rows.forEach(row => {
        const studentId = row.cells[0].textContent.toLowerCase();
        const studentName = row.cells[1].textContent.toLowerCase();
        
        if (studentId.includes(searchTerm) || studentName.includes(searchTerm)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});

// Make functions available globally
window.generatePinkSlip = generatePinkSlip;
window.viewPinkSlip = viewPinkSlip;
window.viewAttendanceHistory = viewAttendanceHistory;

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    console.log('Page loaded, initializing student status...');
    loadStudentStatus();
}); 