// Authentication functions
async function signIn(email, password) {
    try {
        const { data, error } = await window.supabase.auth.signInWithPassword({
            email,
            password
        })
        if (error) throw error
        return data
    } catch (error) {
        console.error('Error signing in:', error)
        throw error
    }
}

async function signOut() {
    try {
        const { error } = await window.supabase.auth.signOut()
        if (error) throw error
        window.location.href = 'login.html'
    } catch (error) {
        console.error('Error signing out:', error)
        throw error
    }
}

// Check authentication status
async function checkAuth() {
    try {
        const { data: { user } } = await window.supabase.auth.getUser()
        if (!user) {
            window.location.href = 'login.html'
        }
        return user
    } catch (error) {
        console.error('Error checking auth:', error)
        window.location.href = 'login.html'
    }
}

// Add sign out button to the header
document.addEventListener('DOMContentLoaded', () => {
    const header = document.querySelector('header nav')
    if (header) {
        const signOutBtn = document.createElement('button')
        signOutBtn.textContent = 'Sign Out'
        signOutBtn.addEventListener('click', signOut)
        header.appendChild(signOutBtn)
    }

    // Check authentication on page load
    checkAuth()

    // Add this check before adding event listeners
    const showRegister = document.getElementById('showRegister');
    if (showRegister) {
        showRegister.addEventListener('click', (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorMessage = document.getElementById('errorMessage');

            if (!email || !password) {
                errorMessage.style.display = 'block';
                errorMessage.textContent = 'Please fill in both email and password fields';
                return;
            }

            // For testing: accept any registration
            errorMessage.style.display = 'block';
            errorMessage.style.color = '#27ae60';
            errorMessage.textContent = 'Registration successful! You can now login.';
        });
    }

    // Check if already logged in
    if (localStorage.getItem('isAuthenticated') === 'true') {
        window.location.href = 'index.html';
    }
})

// Simple authentication for testing
function checkAuth() {
    // For testing, we'll just check if user is logged in
    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    if (!isAuthenticated) {
        window.location.href = 'login.html';
    }
}

// Handle login form submission
document.getElementById('loginForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // For testing: accept any email and password
    if (email && password) {
        localStorage.setItem('isAuthenticated', 'true');
        localStorage.setItem('userEmail', email);
        window.location.href = 'index.html';
    } else {
        const errorMessage = document.getElementById('errorMessage');
        errorMessage.style.display = 'block';
        errorMessage.textContent = 'Please enter both email and password';
    }
});

// Handle sign out
function signOut() {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('userEmail');
    window.location.href = 'login.html';
}

// Check authentication on page load
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
}); 