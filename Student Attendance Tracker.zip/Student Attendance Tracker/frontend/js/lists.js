// Function to load students list
async function loadStudentsList() {
    const loadingMsg = document.getElementById('loadingMsg');
    const noStudentsMsg = document.getElementById('noStudentsMsg');
    const studentsTable = document.getElementById('studentsTable');
    const tbody = studentsTable ? studentsTable.querySelector('tbody') : null;
    if (loadingMsg) loadingMsg.style.display = '';
    if (noStudentsMsg) noStudentsMsg.style.display = 'none';
    if (studentsTable) studentsTable.style.display = 'none';
    try {
        const { data: students, error } = await window.supabase
            .from('students')
            .select(`
                *,
                courses (name)
            `)
            .order('name');
        if (error) {
            throw error;
        }
        if (students && students.length > 0) {
            if (tbody) {
                tbody.innerHTML = students.map(student => `
                    <tr>
                        <td>${student.student_id}</td>
                        <td>${student.name}</td>
                        <td>${student.email}</td>
                        <td>${student.phone || '-'}</td>
                        <td>${student.courses?.name || 'No Course'}</td>
                        <td>
                            <button class="btn btn-danger" onclick="deleteStudent('${student.id}')">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </td>
                    </tr>
                `).join('');
            }
            if (studentsTable) studentsTable.style.display = '';
            if (noStudentsMsg) noStudentsMsg.style.display = 'none';
        } else {
            if (tbody) tbody.innerHTML = '';
            if (studentsTable) studentsTable.style.display = 'none';
            if (noStudentsMsg) noStudentsMsg.style.display = 'block';
        }
    } catch (error) {
        if (tbody) tbody.innerHTML = '';
        if (studentsTable) studentsTable.style.display = 'none';
        if (noStudentsMsg) {
            noStudentsMsg.textContent = 'Error loading students: ' + error.message;
            noStudentsMsg.style.display = 'block';
        }
    } finally {
        if (loadingMsg) loadingMsg.style.display = 'none';
    }
}

// Load appropriate list based on current page
document.addEventListener('DOMContentLoaded', () => {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    if (currentPage === 'students-list.html') {
        loadStudentsList();
    } else if (currentPage === 'courses-list.html') {
        loadCoursesList();
    } else if (currentPage === 'attendance-list.html') {
        loadTodayAttendance();
    }
});

// Make the function available globally
window.loadStudentsList = loadStudentsList;

// Function to load courses list
async function loadCoursesList() {
    const coursesTable = document.getElementById('coursesTable');
    const loadingMsg = document.getElementById('loadingMsg');
    const noCoursesMsg = document.getElementById('noCoursesMsg');
    const tbody = coursesTable.querySelector('tbody');
    tbody.innerHTML = '';
    loadingMsg.style.display = 'block';
    coursesTable.style.display = 'none';
    noCoursesMsg.style.display = 'none';
    try {
        const { data: courses, error } = await window.supabase
            .from('courses')
            .select('*')
            .order('code');
            
        if (error) throw error;
        
        if (courses && courses.length > 0) {
            courses.forEach(course => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${course.code}</td>
                    <td>${course.name}</td>
                    <td>${course.description || '-'}</td>
                `;
                tbody.appendChild(tr);
            });
            coursesTable.style.display = 'table';
            noCoursesMsg.style.display = 'none';
        } else {
            coursesTable.style.display = 'none';
            noCoursesMsg.style.display = 'block';
        }
    } catch (error) {
        console.error('Error loading courses:', error);
        coursesTable.style.display = 'none';
        noCoursesMsg.textContent = 'Error loading courses: ' + error.message;
        noCoursesMsg.style.display = 'block';
    } finally {
        loadingMsg.style.display = 'none';
    }
}

// Function to load today's attendance
async function loadTodayAttendance() {
    try {
        // Get date from URL parameter or use today's date
        const urlParams = new URLSearchParams(window.location.search);
        const date = urlParams.get('date');

        // Build the query
        let query = window.supabase
            .from('attendance')
            .select(`
                *,
                students (name, student_id),
                courses (name)
            `);

        // If a specific date is provided, filter by it
        if (date) {
            query = query.eq('date', date);
        }

        // Order by date (newest first) and then by created_at
        const { data: attendance, error } = await query
            .order('date', { ascending: false })
            .order('created_at', { ascending: false });

        if (error) {
            console.error('Error loading attendance:', error);
            throw error;
        }

        const attendanceTable = document.getElementById('attendanceTable');
        const noRecordsMessage = document.getElementById('noRecordsMessage');
        const loadingMessage = document.getElementById('loadingMessage');

        if (loadingMessage) {
            loadingMessage.style.display = 'none';
        }

        if (!attendance || attendance.length === 0) {
            if (attendanceTable) attendanceTable.style.display = 'none';
            if (noRecordsMessage) {
                noRecordsMessage.textContent = date ? 
                    `No attendance records found for ${new Date(date).toLocaleDateString()}.` :
                    'No attendance records found.';
                noRecordsMessage.style.display = 'block';
            }
            return;
        }

        // Group attendance by status
        const groupedAttendance = {
            present: attendance.filter(record => record.status === 'present'),
            late: attendance.filter(record => record.status === 'late'),
            absent: attendance.filter(record => record.status === 'absent')
        };

        if (attendanceTable) {
            attendanceTable.style.display = 'table';
            const tbody = attendanceTable.querySelector('tbody');
            if (tbody) {
                tbody.innerHTML = `
                    <tr class="status-header">
                        <td colspan="6">Present (${groupedAttendance.present.length})</td>
                    </tr>
                    ${groupedAttendance.present.map(record => `
                        <tr>
                            <td>${record.students?.student_id || 'N/A'}</td>
                            <td>${record.students?.name || 'N/A'}</td>
                            <td>${record.courses?.name || 'No Course'}</td>
                            <td>Present</td>
                            <td>${new Date(record.created_at).toLocaleTimeString()}</td>
                            <td>${new Date(record.date).toLocaleDateString()}</td>
                        </tr>
                    `).join('')}
                    <tr class="status-header">
                        <td colspan="6">Late (${groupedAttendance.late.length})</td>
                    </tr>
                    ${groupedAttendance.late.map(record => `
                        <tr>
                            <td>${record.students?.student_id || 'N/A'}</td>
                            <td>${record.students?.name || 'N/A'}</td>
                            <td>${record.courses?.name || 'No Course'}</td>
                            <td>Late</td>
                            <td>${new Date(record.created_at).toLocaleTimeString()}</td>
                            <td>${new Date(record.date).toLocaleDateString()}</td>
                        </tr>
                    `).join('')}
                    <tr class="status-header">
                        <td colspan="6">Absent (${groupedAttendance.absent.length})</td>
                    </tr>
                    ${groupedAttendance.absent.map(record => `
                        <tr>
                            <td>${record.students?.student_id || 'N/A'}</td>
                            <td>${record.students?.name || 'N/A'}</td>
                            <td>${record.courses?.name || 'No Course'}</td>
                            <td>Absent</td>
                            <td>${new Date(record.created_at).toLocaleTimeString()}</td>
                            <td>${new Date(record.date).toLocaleDateString()}</td>
                        </tr>
                    `).join('')}
                `;
            }
        }

        if (noRecordsMessage) {
            noRecordsMessage.style.display = 'none';
        }

        // Update page title
        const header = document.querySelector('header h1');
        if (header) {
            header.textContent = date ? 
                `Attendance for ${new Date(date).toLocaleDateString()}` :
                'All Attendance Records';
        }
    } catch (error) {
        console.error('Error loading attendance:', error);
        alert('Error loading attendance: ' + error.message);
    }
}

// Update the recent attendance display in the dashboard
async function loadRecentAttendance() {
    try {
        const { data: attendance, error } = await window.supabase
            .from('attendance')
            .select(`
                *,
                students (name, student_id),
                courses (name)
            `)
            .order('date', { ascending: false })
            .limit(5);

        if (error) {
            console.error('Error loading recent attendance:', error);
            throw error;
        }

        const recentAttendanceList = document.getElementById('recentAttendanceList');
        if (recentAttendanceList) {
            recentAttendanceList.innerHTML = attendance.map(record => `
                <tr>
                    <td>${record.students?.student_id || 'N/A'}</td>
                    <td>${record.students?.name || 'N/A'}</td>
                    <td>${record.courses?.name || 'No Course'}</td>
                    <td>${record.status.charAt(0).toUpperCase() + record.status.slice(1)}</td>
                    <td>${new Date(record.date).toLocaleDateString()}</td>
                </tr>
            `).join('');
        }
    } catch (error) {
        console.error('Error loading recent attendance:', error);
    }
}

// Function to delete a student
async function deleteStudent(studentId) {
    if (!confirm('Are you sure you want to delete this student? This will also delete all their attendance records, late tracking, and pink slips.')) {
        return;
    }

    try {
        // First delete related records
        console.log('Deleting related records for student:', studentId);

        // Delete attendance records
        const { error: attendanceError } = await window.supabase
            .from('attendance')
            .delete()
            .eq('student_id', studentId);

        if (attendanceError) throw attendanceError;

        // Delete late tracking records
        const { error: lateError } = await window.supabase
            .from('late_tracking')
            .delete()
            .eq('student_id', studentId);

        if (lateError) throw lateError;

        // Delete pink slips
        const { error: pinkSlipError } = await window.supabase
            .from('pink_slips')
            .delete()
            .eq('student_id', studentId);

        if (pinkSlipError) throw pinkSlipError;

        // Finally delete the student
        const { error: studentError } = await window.supabase
            .from('students')
            .delete()
            .eq('id', studentId);

        if (studentError) throw studentError;

        alert('Student deleted successfully!');
        loadStudentsList(); // Refresh the list

    } catch (error) {
        console.error('Error deleting student:', error);
        alert('Error deleting student: ' + error.message);
    }
}

// Make the function available globally
window.deleteStudent = deleteStudent; 