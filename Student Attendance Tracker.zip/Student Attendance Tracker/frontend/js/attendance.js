// Load students for attendance marking
async function loadStudentsForAttendance(courseId) {
    try {
        const { data: students, error } = await supabase
            .from('students')
            .select('*')
            .order('name')
        
        if (error) throw error

        const studentList = document.getElementById('studentList')
        studentList.innerHTML = ''

        students.forEach(student => {
            const div = document.createElement('div')
            div.className = 'student-attendance-item'
            div.innerHTML = `
                <input type="checkbox" id="student_${student.id}" name="attendance" value="${student.id}">
                <label for="student_${student.id}">${student.name}</label>
            `
            studentList.appendChild(div)
        })
    } catch (error) {
        alert('Error loading students: ' + error.message)
    }
}

// Load courses for attendance marking
async function loadCourses() {
    try {
        const { data: courses, error } = await window.supabase
            .from('courses')
            .select('*')
            .order('name')
        
        if (error) throw error

        const courseSelect = document.getElementById('courseSelect')
        const reportCourse = document.getElementById('reportCourse')
        
        courses.forEach(course => {
            const option = new Option(course.name, course.id)
            courseSelect.add(option)
            reportCourse.add(new Option(course.name, course.id))
        })
    } catch (error) {
        alert('Error loading courses: ' + error.message)
    }
}

// Mark attendance
document.getElementById('markAttendanceForm').addEventListener('submit', async (e) => {
    e.preventDefault()
    const courseId = document.getElementById('courseSelect').value
    const date = document.getElementById('date').value
    const presentStudents = Array.from(document.querySelectorAll('input[name="attendance"]:checked'))
        .map(checkbox => checkbox.value)

    try {
        const { data, error } = await supabase
            .from('attendance')
            .insert(presentStudents.map(studentId => ({
                student_id: studentId,
                course_id: courseId,
                date,
                present: true
            })))
        
        if (error) throw error
        alert('Attendance marked successfully!')
        e.target.reset()
    } catch (error) {
        alert('Error marking attendance: ' + error.message)
    }
})

// Generate report
document.getElementById('generateReport').addEventListener('click', async () => {
    const courseId = document.getElementById('reportCourse').value
    const date = document.getElementById('reportDate').value

    try {
        let query = supabase
            .from('attendance')
            .select(`
                *,
                students (name),
                courses (name)
            `)
        
        if (courseId) {
            query = query.eq('course_id', courseId)
        }
        if (date) {
            query = query.eq('date', date)
        }

        const { data, error } = await query
        
        if (error) throw error

        const reportResults = document.getElementById('reportResults')
        reportResults.innerHTML = `
            <h3>Attendance Report</h3>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Course</th>
                        <th>Student</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    ${data.map(record => `
                        <tr>
                            <td>${record.date}</td>
                            <td>${record.courses.name}</td>
                            <td>${record.students.name}</td>
                            <td>${record.present ? 'Present' : 'Absent'}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `
    } catch (error) {
        alert('Error generating report: ' + error.message)
    }
})

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadCourses()
}) 