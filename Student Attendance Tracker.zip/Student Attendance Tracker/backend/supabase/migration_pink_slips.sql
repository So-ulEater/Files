-- Create table for late tracking
CREATE TABLE IF NOT EXISTS late_tracking (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    student_id UUID REFERENCES students(id) NOT NULL,
    course_id UUID REFERENCES courses(id) NOT NULL,
    date DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(student_id, course_id, date)  -- Add unique constraint to prevent duplicate late records
);

-- Create table for pink slips
CREATE TABLE IF NOT EXISTS pink_slips (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    student_id UUID REFERENCES students(id) NOT NULL,
    course_id UUID REFERENCES courses(id) NOT NULL,
    issue_date DATE NOT NULL,
    reason TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(student_id, course_id)  -- Add unique constraint for student-course combination
);

-- Create function to check and create pink slip
CREATE OR REPLACE FUNCTION check_and_create_pink_slip()
RETURNS TRIGGER AS $$
BEGIN
    -- Check if student has 3 late instances in the last 30 days
    IF EXISTS (
        SELECT 1
        FROM late_tracking
        WHERE student_id = NEW.student_id
        AND course_id = NEW.course_id
        AND date >= CURRENT_DATE - INTERVAL '30 days'
        GROUP BY student_id, course_id
        HAVING COUNT(*) >= 3
    ) THEN
        -- Create pink slip if it doesn't exist
        INSERT INTO pink_slips (student_id, course_id, issue_date, reason)
        VALUES (
            NEW.student_id,
            NEW.course_id,
            CURRENT_DATE,
            'Three late instances in 30 days'
        )
        ON CONFLICT (student_id, course_id) DO NOTHING;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for late tracking
DROP TRIGGER IF EXISTS check_late_instances ON late_tracking;
CREATE TRIGGER check_late_instances
AFTER INSERT ON late_tracking
FOR EACH ROW
EXECUTE FUNCTION check_and_create_pink_slip();

-- Disable RLS for new tables
ALTER TABLE late_tracking DISABLE ROW LEVEL SECURITY;
ALTER TABLE pink_slips DISABLE ROW LEVEL SECURITY;
ALTER TABLE user_roles DISABLE ROW LEVEL SECURITY;

-- Create policies for new tables
CREATE POLICY "Allow all authenticated users to read late tracking"
    ON late_tracking FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Allow all authenticated users to insert late tracking"
    ON late_tracking FOR INSERT
    TO authenticated
    WITH CHECK (true);

CREATE POLICY "Allow all authenticated users to read pink slips"
    ON pink_slips FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Allow all authenticated users to insert pink slips"
    ON pink_slips FOR INSERT
    TO authenticated
    WITH CHECK (true);

CREATE POLICY "Allow all authenticated users to read user roles"
    ON user_roles FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Allow all authenticated users to insert user roles"
    ON user_roles FOR INSERT
    TO authenticated
    WITH CHECK (true); 